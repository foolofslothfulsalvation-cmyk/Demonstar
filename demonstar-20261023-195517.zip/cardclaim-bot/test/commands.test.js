import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import test from 'node:test';

import { handleCommand } from '../src/commands.js';
import { makeConfig } from './helpers.js';

async function run(text, overrides = {}) {
	const config = makeConfig({});
	const sent = [];
	const claimer = {
		stats: { detected: 0, claimed: 0, skipped: 0, failed: 0, dryRun: 0, confirmed: 0 },
		isPaused: () => false,
		setPaused: () => false,
		pendingCount: () => 0,
		...overrides.claimer,
	};
	const sock = { user: { id: '2349153327424@s.whatsapp.net' } };
	const logger = { warn: () => {} };
	return await handleCommand({
		text,
		config,
		configPath: tempFile(config),
		claimer,
		sock,
		logger,
	});
}

function tempFile(content) {
	const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'demonstar-commands-'));
	const file = path.join(dir, 'config.json');
	fs.writeFileSync(file, JSON.stringify(content));
	return file;
}

test('.status shows connection, mode, limits', async () => {
	const reply = await run('.status');
	assert.ok(reply.includes('Connection:'));
	assert.ok(reply.includes('IV='));
	assert.ok(reply.includes('/min'));
	assert.ok(reply.includes('Limits:'));
});

test('.pause pauses and .resume resumes', async () => {
	const config = makeConfig({});
	let paused = false;
	const claimer = {
		stats: { detected: 0, claimed: 0, skipped: 0, failed: 0, dryRun: 0, confirmed: 0 },
		isPaused: () => paused,
		setPaused: (p) => {
			paused = p;
		},
		pendingCount: () => 0,
	};
	const configPath = tempFile(config);
	await handleCommand({
		text: '.pause',
		config,
		configPath,
		claimer,
		sock: { user: { id: '2349153327424@s.whatsapp.net' } },
		logger: { warn: () => {} },
	});
	assert.equal(paused, true);
	await handleCommand({
		text: '.resume',
		config,
		configPath,
		claimer,
		sock: { user: { id: '2349153327424@s.whatsapp.net' } },
		logger: { warn: () => {} },
	});
	assert.equal(paused, false);
	assert.equal(config.paused, false);
});

test('.rates shows tier rates and limits', async () => {
	const reply = await run('.rates');
	assert.ok(reply.includes('Tier IV:'));
	assert.ok(reply.includes('Limits:'));
	assert.ok(reply.includes('100/min'));
});

test('.set t4 50 changes tier probability and enables it', async () => {
	const reply = await run('.set t4 50');
	assert.ok(reply.includes('Tier IV set to 50%'));
});

test('.set dryrun off turns off dry run', async () => {
	const reply = await run('.set dryrun off');
	assert.ok(reply.includes('Dry run is now OFF'));
});

test('.block and .unblock manage blocked groups', async () => {
	const block = await run('.block 120363000000000002@g.us');
	assert.ok(block.includes('Blocked'));
	const unblock = await run('.unblock 120363000000000002@g.us');
	assert.ok(unblock.includes('Unblocked'));
});

test('unknown command returns help hint', async () => {
	const reply = await run('.nonsense');
	assert.ok(reply.includes('Unknown command'));
});

test('persists changes by reading back config file', async () => {
	const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'demonstar-persist-'));
	const file = path.join(dir, 'config.json');
	fs.writeFileSync(file, JSON.stringify(makeConfig({})));

	const claimer = {
		stats: { detected: 0, claimed: 0, skipped: 0, failed: 0, dryRun: 0, confirmed: 0 },
		isPaused: () => false,
		setPaused: () => {},
		pendingCount: () => 0,
	};
	await handleCommand({
		text: '.set t3 90',
		config: makeConfig({}),
		configPath: file,
		claimer,
		sock: { user: { id: '2349153327424@s.whatsapp.net' } },
		logger: { warn: () => {} },
	});
	const reloaded = JSON.parse(fs.readFileSync(file, 'utf8'));
	assert.equal(reloaded.tiers[3].probability, 0.9);
	assert.equal(reloaded.tiers[3].enabled, true);
	fs.rmSync(dir, { recursive: true, force: true });
});
